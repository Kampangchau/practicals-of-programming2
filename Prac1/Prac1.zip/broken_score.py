score = float(input("Enter score: "))
if 100 >= score >= 90:
    print("Excellent")
elif 89 >= score >= 50:
    print("Passable")
else:
    print("Bad")