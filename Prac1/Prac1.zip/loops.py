for o in range(1, 21, 2):
    print(o, end=' ')
print()

#a
for a in range(0, 101, 10):
    print(a, end=' ')
print()

#b
for b in range(20, 0, 19):
    print(b, end=' ')
print()

#c
number_of_stars = int(input("Number of stars: "))
for c in range(number_of_stars):
    print(c, end=' ')
print()

#d
for d in range(1, number_of_stars + 1):
    print('*' * d)
print()